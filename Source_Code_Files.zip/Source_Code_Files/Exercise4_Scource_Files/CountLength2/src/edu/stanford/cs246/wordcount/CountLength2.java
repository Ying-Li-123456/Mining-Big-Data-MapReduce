package edu.stanford.cs246.wordcount;

import java.io.IOException;
import java.util.Arrays;
import java.util.Random;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

public class CountLength2 extends Configured implements Tool {

    public static void main(String[] args) throws Exception {
        System.out.println(Arrays.toString(args));
        Configuration conf = new Configuration();
        Path path = new Path(args[1]);
        FileSystem fileSystem = path.getFileSystem(conf);
        if(fileSystem.exists(path)){
                fileSystem.delete(path,true);
        }

        //the first round mapReduce
        Job job = new Job(conf, "CountLength2");
        job.setJarByClass(CountLength2.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(NullWritable.class);

        job.setMapperClass(Map.class);
        job.setReducerClass(Reduce.class);

        //temporary file dictionary
        FileInputFormat.addInputPath(job,new Path(args[0]));
        Path tempDir = new Path("temp-"+Integer.toString(new Random().nextInt(Integer.MAX_VALUE)));
        FileOutputFormat.setOutputPath(job,tempDir);
        Job job2 = new Job(conf, "CountLength2");
        job2.setJarByClass(CountLength2.class);
        if(job.waitForCompletion(true)){

            FileInputFormat.addInputPath(job2,tempDir);
            //the second round mapReduce
            job2.setMapperClass(Map2.class);
            job2.setReducerClass(Reduce2.class);
            FileOutputFormat.setOutputPath(job2, new Path(args[1]));
            job2.setOutputKeyClass(IntWritable.class);
            job2.setOutputValueClass(IntWritable.class);
            FileSystem.get(conf).deleteOnExit(tempDir);
        }

        System.exit(job2.waitForCompletion(true)?0:1);
    }

    @Override
    public int run(String[] args) throws Exception {
        System.out.println(Arrays.toString(args));

        Configuration conf = new Configuration();
        Path path = new Path(args[1]);
        FileSystem fileSystem = path.getFileSystem(conf);
        if(fileSystem.exists(path)){
            fileSystem.delete(path,true);
        }

        //the first round mapreduce
        Job job = new Job(getConf(), "WordCount");
        job.setJarByClass(CountLength2.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(NullWritable.class);

        job.setMapperClass(Map.class);
        job.setReducerClass(Reduce.class);

        //temporary file dictionary
        FileInputFormat.addInputPath(job,new Path(args[0]));
        Path tempDir = new Path("temp-"+Integer.toString(new Random().nextInt(Integer.MAX_VALUE)));
        FileOutputFormat.setOutputPath(job,tempDir);
        Job job2 = new Job(getConf(), "WordCount");
        if(job.waitForCompletion(true)){

            FileInputFormat.addInputPath(job2,tempDir);
            //the second round mapreduce
            job2.setMapperClass(Map2.class);
            job2.setReducerClass(Reduce2.class);
            FileOutputFormat.setOutputPath(job2, new Path(args[1]));
            job2.setOutputValueClass(IntWritable.class);
            job2.setOutputValueClass(IntWritable.class);
            FileSystem.get(conf).deleteOnExit(tempDir);
        }
        job2.waitForCompletion(true);
        return 0;
    }

    public static class Map extends Mapper<LongWritable, Text, Text, NullWritable> {

        @Override
        public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
            String line = value.toString();
            String result = line.replaceAll("\\p{Punct}", "");
            String lowerCase = result.toLowerCase();
            String words[]=lowerCase.split("\\s");

           for(String word : words){
               context.write(new Text(word),NullWritable.get());
           }
        }
    }

    public static class Reduce extends Reducer<Text, NullWritable, Text, NullWritable> {
        @Override
        public void reduce(Text key, Iterable<NullWritable> values, Context context)
                        throws IOException, InterruptedException {
                context.write(key, NullWritable.get());
        }
    }

    public static class Map2 extends Mapper<LongWritable, Text, IntWritable, IntWritable> {

        @Override
        public void map(LongWritable key, Text value,  Context context)
                        throws IOException, InterruptedException {

            String oneWord = value.toString();
            int length = oneWord.length();

            context.write(new IntWritable(length),new IntWritable(1));
        }
    }

    public static class Reduce2 extends Reducer<IntWritable, IntWritable, IntWritable, IntWritable> {
        public void reduce(IntWritable key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException {
            int sum=0;
            for(IntWritable val:values){
                sum += val.get();
            }
            context.write(key, new IntWritable(sum));
        }
    }
}
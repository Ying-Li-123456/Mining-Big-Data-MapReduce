# =========================================
#  Mining Big Data Assignment 1 Group 58
#  Student name: Jingyi Cui
#  Student id: a1787453
#  Email: a1787453@student.adelaide.edu.au
#  Student name: Ying Li
#  Student id: a1776903
#  Email: a1776903@student.adelaide.edu.au
#  Semester: s1
#  Year: 2021
# =========================================


Exercise 4:

// ****************************** Part 1   Project name: CountLength1 *************************************//

// =============== For the first inputfile ===================//
Run code in standalone mode:
1. Open Eclipse -> File -> Import: import the FriendsRecommendation project
2. Right-click on the project and select Run As -> Run Configurations.
3. In the pop-up dialog, select the Java Application node and click the New launch configuration button in the upper left corner.
4. Enter a name (e.g:CountLength1Driver) in the Name field;
Enter the name of the main class(e.g: edu.stanford.cs246.wordcount.CountLength1) in the Main class field.
5. Switch to the Arguments tab and input the required arguments(e.g: pg100.txt pg100_output). Click Apply.
6. Click on the Run button to run the job immediately.
7. After running, a new folder named pg100_output appears in the CountLength1 folder.

Run code in pseudo-distributed mode:
1. Right-click on the project and select Export.
2. In the pop-up dialog, expand the Java node and select JAR file. Click Next.
3. Browser the export destination and select the CountLength1 folder and name the jar, click finish.(e.g: CountLength1/CountLength1.jar)
4. Open a terminal, go to the CountLength1 repository and run the following command one by one:
hadoop fs -put pg100.txt
hadoop jar CountLength1.jar ./pg100.txt ./pg100_output
hadoop fs -ls pg100_output
hadoop fs -cat pg100_output/part\*

// =============== For the second inputfile ===================//

Run code in standalone mode:
1. Open Eclipse -> File -> Import: import the FriendsRecommendation project
2. Right-click on the project and select Run As -> Run Configurations.
3. In the pop-up dialog, select the Java Application node and click the New launch configuration button in the upper left corner.
4. Enter a name (e.g:CountLength1Driver) in the Name field;
Enter the name of the main class(e.g: edu.stanford.cs246.wordcount.CountLength1) in the Main class field.
5. Switch to the Arguments tab and input the required arguments(e.g: 3399.txt 3399_output). Click Apply.
6. Click on the Run button to run the job immediately.
7. After running, a new folder named 3399_output appears in the CountLength1 folder.

Run code in pseudo-distributed mode:
1. Right-click on the project and select Export.
2. In the pop-up dialog, expand the Java node and select JAR file. Click Next.
3. Browser the export destination and select the CountLength1 folder and name the jar, click finish.(e.g: CountLength1/CountLength3399.jar)
4. Open a terminal, go to the CountLength1 repository(maybe you are here now) and run the following command one by one:
hadoop fs -put 3399.txt
hadoop jar CountLength3399.jar ./3399.txt ./3399_output
hadoop fs -ls 3399_output
hadoop fs -cat 3399_output/part\*


// ****************************** Part 3   Project name: CountLength2 *************************************//

// =============== For the first inputfile ===================//
Run code in standalone mode:
1. Open Eclipse -> File -> Import: import the FriendsRecommendation project
2. Right-click on the project and select Run As -> Run Configurations.
3. In the pop-up dialog, select the Java Application node and click the New launch configuration button in the upper left corner.
4. Enter a name (e.g:CountLength2Driver) in the Name field;
Enter the name of the main class(e.g: edu.stanford.cs246.wordcount.CountLength2) in the Main class field.
5. Switch to the Arguments tab and input the required arguments(e.g: pg100.txt pg100_output2). Click Apply.
6. Click on the Run button to run the job immediately.
7. After running, a new folder named pg100_output2 appears in the CountLength2 folder.

Run code in pseudo-distributed mode:
1. Right-click on the project and select Export.
2. In the pop-up dialog, expand the Java node and select JAR file. Click Next.
3. Browser the export destination and select the CountLength2 folder and name the jar, click finish.(e.g: CountLength2/CountLength100.jar)
4. Open a terminal, go to the CountLength2 repository and run the following command one by one:
hadoop fs -put pg100.txt
hadoop jar CountLength100.jar ./pg100.txt ./pg100_output2
hadoop fs -ls pg100_output2
hadoop fs -cat pg100_output2/part\*

// =============== For the second inputfile ===================//
Run code in standalone mode:
1. Open Eclipse -> File -> Import: import the FriendsRecommendation project
2. Right-click on the project and select Run As -> Run Configurations.
3. In the pop-up dialog, select the Java Application node and click the New launch configuration button in the upper left corner.
4. Enter a name (e.g:CountLength2Driver) in the Name field;
Enter the name of the main class(e.g: edu.stanford.cs246.wordcount.CountLength2) in the Main class field.
5. Switch to the Arguments tab and input the required arguments(e.g: 3399.txt 3399_output2). Click Apply.
6. Click on the Run button to run the job immediately.
7. After running, a new folder named 3399_output2 appears in the CountLength2 folder.

Run code in pseudo-distributed mode:
1. Right-click on the project and select Export.
2. In the pop-up dialog, expand the Java node and select JAR file. Click Next.
3. Browser the export destination and select the CountLength2 folder and name the jar, click finish.(e.g: CountLength2/CountLength23399.jar)
4. Open a terminal, go to the CountLength2 repository(maybe you are here now) and run the following command one by one:
hadoop fs -put 3399.txt
hadoop jar CountLength23399.jar ./3399.txt ./3399_output2
hadoop fs -ls 3399_output2
hadoop fs -cat 3399_output2/part\*
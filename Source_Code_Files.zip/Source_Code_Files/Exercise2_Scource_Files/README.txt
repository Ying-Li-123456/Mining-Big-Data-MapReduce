# =========================================
#  Mining Big Data Assignment 1 Group 58
#  Student name: Jingyi Cui
#  Student id: a1787453
#  Email: a1787453@student.adelaide.edu.au
#  Student name: Ying Li
#  Student id: a1776903
#  Email: a1776903@student.adelaide.edu.au
#  Semester: s1
#  Year: 2021
# =========================================

Exercise 2:
* Project name: Exercise

Run code in standalone mode:
1. Open Eclipse -> File -> Import: import the Exercise project
2. Right-click on the project and select Run As -> Run Configurations.
3. In the pop-up dialog, select the Java Application node and click the New launch configuration button in the upper left corner.
4. Enter a name (e.g:ExerciseDriver) in the Name field;
Enter the name of the main class(e.g: edu.stanford.cs246.wordcount.Exercise) in the Main class field.
5. Switch to the Arguments tab and input the required arguments(e.g: 100-0.txt output_exercise2). Click Apply.
6. Click on the Run button to run the job immediately.
7. After running, a new folder named output_exercise2 appears in the Exercise folder.

Run code in pseudo-distributed mode:
1. Right-click on the project and select Export.
2. In the pop-up dialog, expand the Java node and select JAR file. Click Next.
3. Browser the export destination and select the Exercise folder and name the jar, click finish.(e.g: Exercise/Exercise.jar)
4. Open a terminal, go to the Exercise repository and run the following command one by one:
hadoop fs -put 100-0.txt
hadoop jar Exercise.jar ./100-0.txt ./output_exercise2
hadoop fs -ls output_exercise2
hadoop fs -cat output_exercise2/part\*

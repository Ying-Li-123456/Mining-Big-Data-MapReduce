package edu.stanford.cs246.wordcount;

import java.io.IOException;
import java.util.*;
import java.util.Map.Entry;
import org.apache.commons.lang.*;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
 
public class FriendsRecommendation extends Configured implements Tool {
	
    public static void main(String[] args) throws Exception {
    	System.out.println(Arrays.toString(args));
    	int res = ToolRunner.run(new Configuration(), new FriendsRecommendation(), args);
    	System.exit(res);
    }   
 
    public static class Map extends Mapper<LongWritable, Text, IntWritable, Text> {
        public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
            String line = value.toString();
            String[] userAndFriends = line.split("\t");
            if (userAndFriends.length == 2) {
                String user = userAndFriends[0];
                IntWritable userKey = new IntWritable(Integer.parseInt(user));
                String[] friends = userAndFriends[1].split(",");
                String recommendation1, recommendation2;
                IntWritable recommendation1Key = new IntWritable();
                Text recommendation1Value = new Text();
                IntWritable recommendation2Key = new IntWritable();
                Text recommendation2Value = new Text();
                for (int i = 0; i < friends.length; i++) {
                	recommendation1 = friends[i];
                	recommendation1Value.set("1," + recommendation1);
                    context.write(userKey, recommendation1Value);   // User and his friends
                    recommendation1Key.set(Integer.parseInt(recommendation1));
                    recommendation1Value.set("2," + recommendation1);
                    for (int j = i+1; j < friends.length; j++) {
                    	recommendation2 = friends[j];
                    	recommendation2Key.set(Integer.parseInt(recommendation2));
                    	recommendation2Value.set("2," + recommendation2);
                        //people who may not friends, and have at least a mutual friend--current user
                        context.write(recommendation1Key, recommendation2Value);    
                        context.write(recommendation2Key, recommendation1Value);   
                    }
                }
            }
        }
    }
 
    public static class Reduce extends Reducer<IntWritable, Text, IntWritable, Text> {
        public void reduce(IntWritable key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
           
        	String[] value;
            HashMap<String, Integer> hash = new HashMap<String, Integer>();
            for (Text val : values) {
                value = (val.toString()).split(",");
                if (value[0].equals("1")) { // ignore the person who is already the friend of the current user
                    hash.put(value[1], -1);
                } else if (value[0].equals("2")) {  // count the number of mutual friends between the user and the person who is not the user's friend
                    if (hash.containsKey(value[1])) {
                        if (hash.get(value[1]) != -1) {
                            hash.put(value[1], hash.get(value[1]) + 1);
                        }
                    } else {
                        hash.put(value[1], 1);                      
                    }
                }
            }
            
            // Convert hash to list 
            ArrayList<Entry<String, Integer>> list = new ArrayList<Entry<String, Integer>>();
            for (Entry<String, Integer> entry : hash.entrySet()) {
             if (entry.getValue() != -1) {  //ignore the persons who are already friends with the user 
                    list.add(entry);
                }
            }
            
            // Sort key-value pairs in the list by the number of mutual friends
            Collections.sort(list, new Comparator<Entry<String, Integer>>() {
                public int compare(Entry<String, Integer> e1, Entry<String, Integer> e2) {
                	//descending order of mutual friends
                	int re = e2.getValue().compareTo(e1.getValue());
                	//when the mutual friends number are equal,sort by ascending  User ID
                	if(re!=0){
                		return re;
                	}else{
                		int num1=Integer.parseInt(e1.getKey());
                		int num2=Integer.parseInt(e2.getKey());
                		if(num1-num2>0){
                			return 1;
                		}else{
                			return -1;
                		}
                	}	                   
                } 
            });
             
            
            int N = 10;
            if (N < 1) {
                context.write(key, new Text(StringUtils.join(list, ",")));
            } else {
                ArrayList<String> recommondation = new ArrayList<String>();
                for (int i = 0; i < Math.min(N, list.size()); i++) {
                	recommondation.add(list.get(i).getKey());
                }
                context.write(key, new Text(StringUtils.join(recommondation, ",")));
            }
        }
    }
    
    @Override
    public int run(String[] args)throws Exception {
    	System.out.println(Arrays.toString(args));
    	Job job = new Job(getConf(), "FriendsRecommendation");
        job.setJarByClass(FriendsRecommendation.class);
        job.setOutputKeyClass(IntWritable.class);
        job.setOutputValueClass(Text.class);
 
        job.setMapperClass(Map.class);
        job.setReducerClass(Reduce.class);
 
        job.setInputFormatClass(TextInputFormat.class);
        job.setOutputFormatClass(TextOutputFormat.class);
 
        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));
 
        job.waitForCompletion(true);    	
    	return 0;
    }
}
